var favShow = "Game of Heros";
console.log(favShow.length);

console.log(favShow[0])

console.log(favShow[12])

console.log(favShow[favShow.length-1])

console.log(favShow.indexOf("of"))
console.log(favShow.slice(4,6))

var srk = "My Name IS ak"
console.log(srk.toUpperCase())
console.log(srk.toLowerCase())
