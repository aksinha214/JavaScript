(function iife(){
    //named iife
    console.log("IIFE")
})();

((name) => {

    //unnamed iife
    console.log(`IIFE 2 ${name}`);
})('akk')