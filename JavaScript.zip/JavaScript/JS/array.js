// const num =new Array(1,3,4,5,7,9,6,5,4,3);

// //push
// num.push(10)

// //Unshift
// num.unshift(6)

// //pop
// num.pop()

// //shift
// num.shift()

// num[0] = {num:"ak"}

// const namess = ['ak','bk','ck','dk','ek','fk','ak']
// // console.log(names)

// //indesOf
// namess.indexOf('dk')
// // console.log(names.indexOf('ak',1))

// //LastIndexOf
// namess.lastIndexOf('ak')

// //includes
// namess.includes('bk')



// //find
// let channels = [
//     {
//         name: 'ak',
//         subs:2300
//     },{
//         name:'bk',
//         subs:330
//     },{
//         name:'ck',
//         subs:4443
//     },{
//         name:'dk',
//         subs : 5522
//     }
// ];
// // console.log(channels.find(function(element){
// //     return element.name === 'dk'
// // }))

// //arrow function
// // console.log(channels.find((elements) => {
// //     return elements.name === 'ak'
// // }))


// let names1 = ['ak','bk','ck']
// let names2 = ['dk','ek','fk','ak']
// // let names3 = names1.concat(names2)

// //Spread Operator
// let names3 = [...names1,...names2]
// // console.log(names3)


// //concat MEthod
// // console.log(names1.concat(names2))

// //slice method
// // console.log(names3.slice(3,6))


// //for loop
// for(let i = 0; i<names.length;i++){
//     // console.log(names[i])
// }

// //for of
// for(let name of names){
//     // console.log(name)
// }

// //for each
// names.forEach(function(name,index){
//     // console.log(name,index)
// })


// //join
// let student = ['s','h','i','v','a'];
// // console.log(student.join('_'))
// student = student.join('_')

//Split
// console.log(students.split('-'))

// let cities = [
//     {name:'mumbai',pop:23244},
//     {name:'Delhi',pop:423234},
//     {name:'rajkot',pop:3343},
//     {name:'patna',pop:232434},
//     {name:'chennai',pop:25343}
// ];

//filter method
// console.log(cities.filter(city => {
//     return city.pop > 300000
// }))



//Map method
// console.log(cities.map(city => {
//     return city.pop * 2
// }))

const characters = [
    {
        name: 'jethalal',
        height : '172',
        mass: '77',
        eye_color : 'brown',
        gender: 'male'
    },
    {
        name: 'tarika',
        height : '182',
        mass: '79',
        eye_color : 'blue',
        gender: 'female'
    }
    ,{
        name: 'bikash',
        height : '172',
        mass: '75',
        eye_color : 'brown',
        gender: 'male'
    }
    ,{
        name: 'rajdeep',
        height : '192',
        mass: '70',
        eye_color : 'brown',
        gender: 'male'
    },
    {
        name: 'abhishek',
        height : '162',
        mass: '87',
        eye_color : 'blue',
        gender: 'male'
    }
];

//get an elements of name arrays
const name4 = characters.map(ch => ch.name)
console.log(name4);

//get an array just name and height 
const propertiesOfCh = characters.map(ch => {
    return {
        name : ch.name,
        height: ch.height
    }
})
console.log(propertiesOfCh);

//get the total height of all characters
const totalHeight = characters.reduce((prevHeight, character) => {
    return prevHeight + Number(character.height) ;
},0);
console.log(totalHeight)

//get character with mass greater than 100
const greaterMass = characters.filter((character) => {
    return character.mass > 70
})
console.log(greaterMass)

//get all male character
const MaleCh = characters.filter((character) => {
    return character.gender == 'male';
})
console.log(MaleCh)

//sort by name
const SortByName = characters.sort((character1,character2) => {
     if(character1.name < character2.name)
     {
        return -1;
     }
     if(character1.name > character2.name){
        return 1;
     }
     return 0;
})
console.log(SortByName)

// sort by gender

const SortByGender = characters.sort((character1, character2) => {
    if(character1.gender > character2.gender)
    {
        return -1;
    }
    if(character1.gender < character2.gender)
    {
        return 1;
    }
    return 0;
})
console.log(SortByGender)

//Does any character have  mass more than 70
console.log(characters.every((character)=>{
    return character.mass > 70

}))

//Does every character have blue eyes
console.log(characters.every((character)=> {
    return character.eye_color == 'blue'
}))

//is there atleast 1 male character
console.log(characters.some((character) => character.gender == 'male'))

//is there at least one character taller than 200
console.log(characters.some((character) => character.height > 200)) 