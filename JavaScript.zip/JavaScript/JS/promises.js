const ticket = new Promise(function(resolve,reject){
    const isBorded = true;
    if(isBorded)
    {
        resolve("You are not in the flight");
    }else{
        reject("Your flight has een cancelled")
    }
})

ticket.then((data) => {
    console.log("wohoo",data)
}).catch((data) => {
    console.log("oh no",data)
})
.finally(() => {
    console.log("Always excuted")
});