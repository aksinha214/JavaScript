//Declaring a class
// class Product {
//     constructor(itemName,price,discount,productCode)
//     {
//         this.itemName = itemName;
//         this.price = price;
//         this.discount = discount;
//         this.productCode = productCode;
//     }
// }

// let pencil = new Product('Pencil',45,5,'P10');

// const Product1 = class{
//     constructor(itemName,price,discount,productCode)
//     {
//         this.itemName = itemName;
//         this.price = price;
//         this.discount = discount;
//         this.productCode = productCode;
//     }
//     //getter method
//     get getDiscountValue(){
//         return this.discount
//     }
//     //Setter method
//     set setDiscountValue(value){
//         this.discount = value;
//     }

//     discountValue(){
//         return this.discount* this.price/100
//     }
// };

// let chair = new Product1('Chair',499,15,'C10')

class Product {
    constructor(itemName)
    {
        this.itemName = itemName;  
    }
    getItemName(){
        return this.itemName + " is a Product";
    }
}

class Furniture extends Product {
    constructor(itemName){
        super(itemName);
    }

    getItemName(){
        return this.itemName + " is a furniture";
    }
}
let pencil = new Product('Pencil',45,5,'P10');
let chair = new Furniture('Chair',499,15,'C10')


