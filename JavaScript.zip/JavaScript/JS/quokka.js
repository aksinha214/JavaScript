var x = 52, y=10;
x= x%y;
x

var a=10,b=2;
a = a**b;
a

var d = 3 == 3;
d


var d = 3 == '3';
d

var d = 3 === '3';
d

var d = 3 !== '4';
d

var d = 3 >= '4';
d

var d = 3 < '4';
d

var y = 8;
--y;
y

var y = true;
y=+y;
y

var y = "Jai" , z="ho";
y=y + " " + z;
y





