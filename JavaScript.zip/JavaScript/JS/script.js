let clickBtn = document.querySelector('button');
clickBtn.addEventListener('click',inputMsg);

function inputMsg(){
    // alert("Button clicked");
    let name = prompt('Enter new name for button');
    clickBtn.textContent = 'Name:'+ name;
}