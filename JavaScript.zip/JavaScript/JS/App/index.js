//document.getElementById("count-el").innerText = 5;

// let count = 0;

// count = count + 1;


// console.log(count)

function increment(){
    
}