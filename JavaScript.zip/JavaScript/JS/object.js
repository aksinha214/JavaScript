// let lecture = 12;
// let section = 5;
// let title = 'JavaScript';

// const cource = {
//     lecture: 12,
//     section: 3,
//     title:'JavaScript',
//     notes: {
//         introduction:'Welcome to SPE'
//     },
//     enroll()
//     {
//         console.log('You r successfully enroll');

//     }
// }

// // function enroll(){
// //     console.log('You r successfully enroll');
// // }

// cource.enroll()
// console.log(cource.title)
// console.log(cource)

// cource.price=999

//Factory Function
function createCource(title)
{
    return {
        
        title:title,
      
        enroll()
        {
            // console.log('You r successfully enroll');
    
        }
    }
   
}
// const cource = createCource('JavaScript')

// cource.enroll()
// console.log(cource)

//Constructor function

// function Cource(title)
// {
//     this.title = title,
//     this.enroll = function(){
//         console.log('You r successfully enrolled');
//     }

// }

// const cource = new Cource('JavaScript');
// delete cource.title;
// cource.checkEnrollment = function(){
//     console.log('23 students r enrlled');
// }
// cource.enroll()

// console.log(cource)


//constructor method
function Cource(title)
{
    this.title = title,
    this.enroll = function(){
        // console.log('You r successfully enrolled');
    }

}
// const cource = new Cource('JavaScript');
// console.log(cource.constructor)

// const Cource_1 = new Function('title',`
//     this.title = title,
//     this.enroll = function(){
//         console.log('You r successfully enrolled');
//     }
//         `)

// const cource_2 = new Cource_1('JavaScript');
// cource_2.enroll();

//primitive data type
// let number = 10;
// //pass by value
// let number_2 = number;
// number = 15;

// // console.log(number);
// // console.log(number_2);


// //refernce data type
// let obj = {number : 10};
// //pass by refrence
// let obj2 = obj;

// obj.number = 15;

// console.log(obj);
// console.log(obj2)


const cource = {
    title : 'JavaScript',
    enroll(){
        // console.log('You r successfully enrolled');
    }

}

// const cource_1 = {...cource }
// cource_1.title='JAva'

// const cource_1 = Object.assign({},cource)
// cource_1.title = "Java"

// for(let key in cource){
//     console.log(key,cource[key]);
// }


const cource_1 = {};
for(let key of Object.keys(cource))
{
    // console_.log(key,cource[key])
}

//Exercise
//itemname
//price
//discount
//itemcode

const produc = {
    itemName:'Flower',
    price: 50,
    discount : 20,
    itemCode : 'F40'
}

//Factory Function
function createProduct(name, price, discount, itemCode)
{
    return{
        itemName : name,
        price: price,
        discount:discount,
        itemCode: itemCode
    }
}

const football = createProduct('football',400,10,'F30');

//Constructor Function
function Product(name, price, discount, itemCode)
{
    this.itemName = name;
    this.price = price;
    this.discount = discount;
    this.itemCode = itemCode;
    this.discountValue = function(){
        return price * discount/100;
    }
}

const mobile =new Product('OnePlus Nord',30000,5,'OP20')



