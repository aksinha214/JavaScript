// function cookMaggi(maggi, pani, pot){
//     console.log("Your maggi will be ready in "
//         + maggi * 2
//         +" minutes"
//         + " and Ingredient used are:- "
//         + maggi + " Maggi "
//         + pani + " cups of water"
//         + "using " + pot + " pani"
//     )
// }
// cookMaggi(4,8,1);


// function namasteWorld(name,lastName)
// {
//     console.log("Namaste "+ name + " " + lastName);
// }
// namasteWorld("Ak", "doe")
// namasteWorld("kbc"," crore")


function addition(a,b)
{
    return a+b;

}
console.log(addition(6,2))