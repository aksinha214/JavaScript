
// //this keyword
// let counter = createCounter()
// let counter1 = createCounter()

//     function createCounter(){
//         return {
//             count : 0,
//             increment : function (){
//                 this.count++;
//                 console.log(this)
//             }
//         }
//     }

// counter1.increment();
// counter1.increment();
// counter.increment();
// counter.increment();
// console.log(counter1)



// function Car(name){
//     this.name = name;
//     this.start = function(){
//         console.log(this.name + ' started');
//         console.log(this);
//     }

// }
// let swift = new Car('Swift');
// swift.start()



//1.Square root
//Square.side=10
//console.log(square.area)

// let square = {
//     side : 5,
//     get area(){
//       return  this.side ** 2 // this.side
//     }
// }

// square.side = 10
// console.log(square.area)

// //join
// function stringConcat(separator,...strings)
// {
//     let returnVal = ''
//     strings.forEach((string, i) => {
//         if(i == strings.length - 1)
//        {
//          returnVal += string;
//        }else{
//         returnVal += string + separator;

//        }
//     })
//     return returnVal;
// }

// console.log(stringConcat('+','this','is','invalid'))



// //first three value by withou destructing
// arr = [1,2,3,4,5,6,7,8]
// let first = arr[0];
// let second = arr[1];
// let third = arr[2];
// let other = arr.slice(3)

// console.log(first)
// console.log(second)
// console.log(third)
// console.log(other)


// //first three value by destructing
// let [first,second,third,...other] = [1,2,3,4,5,6,7,8]

// console.log(first)
// console.log(second)
// console.log(third)
// console.log(other)


//MatchHouse Stick Problem

function matchHouses(step){
    if(step === 0)
    {
        return 0;
    }else{
        return (step * 6) - (step - 1)
    }
}

console.log(matchHouses(0))
console.log(matchHouses(4))
console.log(matchHouses(87))
