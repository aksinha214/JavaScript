//Objects
// let animal = {
//     name: "dog",
//     legs : 4
// }

// //Dot Notation
// console.log(animal.name);

// //Bracket Notation
// let legsProp = "legs"
// console.log(animal["name"]);
// console.log(animal[legsProp]);


//Arrays
let selectBooks = ["The bad", "The rich", "the poor"];
console.log(selectBooks);
console.log(selectBooks[2])
console.log(selectBooks.length)