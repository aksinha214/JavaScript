// for(let i=0;i<10;i++)
//     {
        
//         console.log("Jai ho");
//     }
// let i=10;
// while(i>0)
//     {
//         console.log("Jai Ho");
//         i--;
//     }


// let j = 0;
// do{
//     console.log("Jai ho");
//     j++;
// }
// while(j<10)

//for...in
//Objects
let animal = {
    name : "tiger",
    leg : 4
};
for(let key in animal)
    {
        console.log(key,animal[key]);
    }
    
//Arrays
let names = ["Ajay","Bikash","jai","raj"];
for(let index in names)
    {
        console.log(index,names[index])
    }

//for...of
for(let name of names){
    console.log(name)
}