$(document).ready(function () {
    'use strict';

    // Initialize dataStorage array from localStorage or as an empty array
    let dataStorage = JSON.parse(localStorage.getItem('formData')) || [];
    if (!Array.isArray(dataStorage)) {
        dataStorage = [];
    }
    let editIndex = null; // Variable to track the index of the row being edited

    // Render the table on page load
    renderTable();

    // Handle form submission
    $('#multiInputForm').on('submit', function (event) {
        event.preventDefault();

        // Check form validity and profession selection
        if (this.checkValidity() === false || !validateProfession()) {
            event.stopPropagation();
            $(this).addClass('was-validated');
            return;
        }

        // Create a FormData object from the form
        const formData = new FormData(this);
        const jsonObject = {};

        // Get form values
        const name = formData.get('name').trim().toLowerCase();
        const email = formData.get('email').trim().toLowerCase();

        // Check for duplicate name and email
        const isDuplicate = dataStorage.some((data, index) => {
            return (data.name.toLowerCase() === name || data.email.toLowerCase() === email) && index !== editIndex;
        });

        if (isDuplicate) {
            alert('The user with this name or email already exists.');
            return;
        }
 
        // Handle file input
        if (formData.has('file')) {
            const file = formData.get('file');
            if (file && file.size > 0) {
                if (!validateFile(file)) {
                    alert('Invalid file type or size.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function (e) {
                    jsonObject['file'] = e.target.result;
                    jsonObject['fileName'] = file.name;
                    collectFormData(formData, jsonObject);
                };
                reader.readAsDataURL(file);
            } else {
                jsonObject['file'] = null;
                jsonObject['fileName'] = '';
                collectFormData(formData, jsonObject);
            }
        } else {
            collectFormData(formData, jsonObject);
        }
    });

    // Collect other form data and store it
    function collectFormData(formData, jsonObject) {
        formData.forEach((value, key) => {
            if (key !== 'file') {
                if (key === 'profession') {
                    if (!jsonObject[key]) {
                        jsonObject[key] = [];
                    }
                    jsonObject[key].push(value); // Collect all selected professions
                } else {
                    jsonObject[key] = value; // Store other form fields
                }
            }
        });

        storeData(jsonObject);
    }

    // Store data in localStorage and render the table
    function storeData(data) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data; // Update existing data
            editIndex = null; // Reset editIndex
        } else {
            dataStorage.push(data); // Add new data
        }
        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage)); // Save to localStorage
            renderTable(); // Render updated table
            $('#multiInputForm').removeClass('was-validated')[0].reset(); // Reset form
        } catch (err) {
            console.log("Error occurred: " + err);
        }
    }

    // Render the table with data from localStorage
    function renderTable() {
        const dataTable = $('#dataTable');
        dataTable.empty(); // Clear existing table rows
        dataStorage.forEach((data, index) => {
            const row = $('<tr>');
            const actions = $('<td>');

            // Create Edit and Delete buttons
            const editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index); // Edit data at the specified index
            });
            const deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index); // Delete data at the specified index
            });
            actions.append(editButton).append(deleteButton);

            // Append data to row
            row.append(actions);
            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));
            row.append($('<td>').html(data.file ? `<a href="${data.file}" download="${data.fileName}">${data.fileName}</a>` : ''));

            dataTable.append(row);
        });
    }

    // Edit data and fill form with existing values
    function editData(index) {
        const data = dataStorage[index];
        editIndex = index; // Set editIndex to the index of the row being edited
        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);
        if (Array.isArray(data.profession)) {
            data.profession.forEach(prof => {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        } else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }
        $('#country').val(data.country);
        $('#textarea').val(data.textarea);
        $('#file').val(''); // Reset the file input as it cannot be pre-filled
    }

    // Delete data from storage and update the table
    function deleteData(index) {
        dataStorage.splice(index, 1); // Remove data at the specified index
        localStorage.setItem('formData', JSON.stringify(dataStorage)); // Update localStorage
        renderTable(); // Render updated table
    }

    // Validate that at least one profession is selected
    function validateProfession() {
        if ($('input[name="profession"]:checked').length === 0) {
            $('input[name="profession"]').each(function () {
                $(this).addClass('is-invalid').css('color', 'red');
            });
            alert("Please select at least one profession.");
            return false;
        } else {
            $('input[name="profession"]').each(function () {
                $(this).removeClass('is-invalid');
            });
            return true;
        }
    }

    // Validate file type and size
    function validateFile(file) {
        const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf']; // Allowed file types
        const maxSize = 5 * 1024 * 1024; // Maximum file size (5MB)
        if (!allowedTypes.includes(file.type) || file.size > maxSize) {
            return false;
        }
        return true;
    }

    // Custom validation for profession checkboxes
    $('input[name="profession"]').on('change', function () {
        validateProfession();
    });
});
