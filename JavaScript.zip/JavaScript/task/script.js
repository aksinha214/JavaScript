$(document).ready(function () {
    'use strict';

    // Initialize dataStorage array from localStorage 
    let dataStorage = JSON.parse(localStorage.getItem('formData')) || [];
    if (!Array.isArray(dataStorage)) {
        dataStorage = [];
    }
    let editIndex = null;


    renderTable();


    $('#multiInputForm').on('submit', function (event) {
        event.preventDefault();

        // Check form validity
        if (this.checkValidity() === false || !validateProfession()) {
            event.stopPropagation();
            $(this).addClass('was-validated');
            return;
        }

        const formData = new FormData(this);
        const jsonObject = {};


        // Get form values
        const name = formData.get('name').trim().toLowerCase();
        const email = formData.get('email').trim().toLowerCase();


        // Check for duplicate name and email
        const isDuplicate = dataStorage.some((data, index) => {

            return (data.name.toLowerCase() === name || data.email.toLowerCase() === email) && index !== editIndex;

        });


        if (isDuplicate) {

            if (name == dataStorage.find(element => element.name == name)?.name) {
                alert("The user with NAME already exist")
            } else {
                alert("The user with EMAIL already exist")
            }
            //alert('The user with this name or email is already exist in the table.');
            return;
        }


        formData.forEach((value, key) => {
            if (key === 'file') {
                const file = this.elements[key].files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        jsonObject[key] = e.target.result;
                        jsonObject[`${key}Name`] = file.name;
                        storeData(jsonObject);
                    };
                    reader.readAsDataURL(file);
                } else {
                    jsonObject[key] = null;
                    storeData(jsonObject);
                }
            } else if (key === 'profession') {
                if (!jsonObject[key]) {
                    jsonObject[key] = [];
                }
                jsonObject[key].push(value); // Collect all selected professions
            } else {
                jsonObject[key] = value; // Store other form fields
            }
        });

        // If no file was uploaded, store data directly
        if (!formData.has('file')) {
            storeData(jsonObject);
        }
    });


    function storeData(data) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data;
            editIndex = null;
        } else {
            dataStorage.push(data);
        }

        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage));
            renderTable();
            $('#multiInputForm').removeClass('was-validated')[0].reset();
        } catch (err) {
            console.log("Error occurred: " + err);
        }
    }


    function renderTable() {
        const dataTable = $('#dataTable');
        dataTable.empty();

        dataStorage.forEach((data, index) => {
            const row = $('<tr>');

            // Create Edit and Delete buttons
            const actions = $('<td>');
            const editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index);
            });
            const deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index);
            });

            actions.append(editButton).append(deleteButton);
            row.append(actions);

            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));
            row.append($('<td>').html(data.file ? `<a href="${data.file}" download="${data.fileName}">${data.fileName}</a>` : ''));

            dataTable.append(row);
        });
    }


    function editData(index) {
        const data = dataStorage[index];
        editIndex = index;

        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);

        if (Array.isArray(data.profession)) {
            data.profession.forEach(prof => {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        } else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }

        $('#country').val(data.country);
        $('#textarea').val(data.textarea);
        $('#file').val('');

    }


    function deleteData(index) {
        dataStorage.splice(index, 1); // Remove data at the specified index
        localStorage.setItem('formData', JSON.stringify(dataStorage));
        renderTable();
    }

    // Validate that at least one profession is selected
    function validateProfession() {
        if ($('input[name="profession"]:checked').length === 0) {
            $('input[name="profession"]').each(function () {
                $(this).addClass('is-invalid').css('color', 'red');
            });
            alert("Please select any one profession")
            return false;
        } else {

            $('input[name="profession"]').each(function () {
                $(this).removeClass('is-invalid');
            });
            return true;
        }
    }

    // Custom validation for profession checkboxes
    $('input[name="profession"]').on('change', function () {
        validateProfession();
    });
});