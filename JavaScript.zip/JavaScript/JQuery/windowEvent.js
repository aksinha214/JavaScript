$(document).ready(function(){
   
   
    //scroll
    $('#box').scroll(function(){
        console.log("U r scrolling")
    });

    //resize
    $(window).resize(function(){
        console.log("U r resizing")
    });

    // //load-->for old version
    // $(window).load(function(){
    //     console.log("U r resizing")
    // });

    // //unload-->for old version
    // $(window).unload(function(){
    //     console.log("U r resizing")
    // });
});