$(document).ready(function(){

    //focus
    $('#sname,#sclass,#scountry').focus(function(){
        $(this).css('background-color','lime');
    });

    //Blur
    $('#sname,#sclass,#scountry').blur(function(){
        $(this).css('background-color','');
    });

    //Change
    $('#scountry').change(function(){
      //  $(this).css('background-color','pink');
      var a = $(this).val();
      $('#test').html(a);
    });

    //select
    $('#sname,#sclass').select(function(){
        $(this).css('background-color','yellow');
    });

    //submit
    $('#sform').submit(function(){
       alert("Form submitted");
    });

});