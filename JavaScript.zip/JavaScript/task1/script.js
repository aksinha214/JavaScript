(function() {
    'use strict';
    
 
    window.addEventListener('load', function() {
        // Get all forms with the class 'needs-validation'
        var forms = document.getElementsByClassName('needs-validation');
 
        // Loop over each form to apply validation and submission handling
        Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
                // Prevent form submission if there are invalid fields
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                } else {
                    // Prevent default form submission
                    event.preventDefault();
 
                    // Create a FormData object from the form
                    const formData = new FormData(event.target);
                    const jsonObject = {};  
 
                    // Iterate over the form data
                    formData.forEach((value, key) => {
                        if (key === 'file') {
                            // Handle file input separately
                            const file = event.target.elements[key].files[0];
                            const reader = new FileReader();
                            
                            // Define the onload event for the FileReader
                            reader.onload = function(e) {
                                jsonObject[key] = e.target.result;  // Add the file data as a base64 string
                                saveData(jsonObject);  // Save the data once the file is read
                            };
                            
                            // Read the file as a Data URL
                            reader.readAsDataURL(file);
                        } else {
                            // Handle other form inputs
                            if (jsonObject[key]) {
                                if (!Array.isArray(jsonObject[key])) {
                                    jsonObject[key] = [jsonObject[key]];
                                }
                                jsonObject[key].push(value);  // Handle multiple selections for checkboxes
                            } else {
                                jsonObject[key] = value;  // Add form data to the object
                            }
                        }
                    });
 
                    // If there is no file input, save the data immediately
                    if (!formData.has('file')) {
                        saveData(jsonObject);
                    }
                }
 
                // Add validation classes to the form
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();
 
// Function to save the form data as a JSON file
function saveData(data) {
    const jsonString = JSON.stringify(data);  // Convert the data to a JSON string
    const blob = new Blob([jsonString], { type: 'application/json' });  // Create a Blob from the JSON string
    const url = URL.createObjectURL(blob);  // Create a URL for the Blob
 
    // Create a temporary link element
    const a = document.createElement('a');
    a.href = url;  // Set the URL as the href of the link
a.download = 'formData.json';  // Set the download attribute to specify the file name
a.click();  // click the link to trigger the download
 
    // Revoke the object URL to free up memory
    URL.revokeObjectURL(url);
}