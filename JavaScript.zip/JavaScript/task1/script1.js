$(document).ready(function () {
    'use strict'
    // Initialize dataStorage array
    let dataStorage = JSON.parse(localStorage.getItem('formData')) || [];
    if (!Array.isArray(dataStorage)) {
        dataStorage = [];
    }
    let editIndex = null;

    // Render table on page load
    renderTable();

    // Handle form submission
    $('#multiInputForm').on('submit', function (event) {
        event.preventDefault();

        if (this.checkValidity() === false) {
            event.stopPropagation();
            $(this).addClass('was-validated');
            return;
        }

        const formData = new FormData(this);
        const jsonObject = {};

        formData.forEach((value, key) => {
            if (key === 'file') {
                const file = this.elements[key].files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        jsonObject[key] = e.target.result;
                        jsonObject[`${key}Name`] = file.name; // Store the file name
                        storeData(jsonObject);
                    };
                    reader.readAsDataURL(file);
                } else {
                    jsonObject[key] = null;
                    storeData(jsonObject);
                }
            } else if (key === 'profession') {
                if (!jsonObject[key]) {
                    jsonObject[key] = [];
                }
                jsonObject[key].push(value);
            } else {
                jsonObject[key] = value;
            }
        });

        // If no file was uploaded, store data directly
        if (!formData.has('file')) {
            storeData(jsonObject);
        }
       

    });


    // Store data in local storage and render table
    function storeData(data) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data;
            editIndex = null;
        } else {
            dataStorage.push(data);
        }
        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage));
            renderTable();
            $('#multiInputForm').removeClass('was-validated')[0].reset();
        }
        catch (err) {
            console.log("Error occured : " + err);
        }
    }

    // Render the table with data
    function renderTable() {
        const dataTable = $('#dataTable');
        dataTable.empty();

        dataStorage.forEach((data, index) => {
            const row = $('<tr>');
            const actions = $('<td>');
            const editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index);
            });
            const deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index);
            });
            actions.append(editButton).append(deleteButton);
            row.append(actions);
            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));
            row.append($('<td>').html(data.file ? `<a href="${data.file}" download>${data.fileName}</a>` : ''));


            dataTable.append(row);
        });
    }

    // Edit data and fill form with existing values
    function editData(index) {
        const data = dataStorage[index];
        editIndex = index;

        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);
        if (Array.isArray(data.profession)) {
            data.profession.forEach(prof => {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        } else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }
        $('#country').val(data.country);
        $('#textarea').val(data.textarea);
        $('#file').val(data.file);
    }

    // Delete data from storage and update table
    function deleteData(index) {
        dataStorage.splice(index, 1);
        localStorage.setItem('formData', JSON.stringify(dataStorage));
        renderTable();
    }


});