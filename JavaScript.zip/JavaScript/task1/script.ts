interface FormData {
    name: string;
    email: string;
    password: string;
    number: string;
    date: string;
    color: string;
    gender: string;
    profession: string[];
    country: string;
    textarea: string;
    file: string | null;
    fileName?: string;
}

$(document).ready(function () {
    'use strict';

    let dataStorage: FormData[] = JSON.parse(localStorage.getItem('formData') || '[]');
    if (!Array.isArray(dataStorage)) {
        dataStorage = [];
    }
    let editIndex: number | null = null;

    renderTable();

    $('#multiInputForm').on('submit', function (event) {
        event.preventDefault();

        if (this.checkValidity() === false || !validateProfession()) {
            event.stopPropagation();
            $(this).addClass('was-validated');
            return;
        }

        const formData = new FormData(this as HTMLFormElement);
        const jsonObject: any = {};

        const name = (formData.get('name') as string).trim().toLowerCase();
        const email = (formData.get('email') as string).trim().toLowerCase();

        const isDuplicate = dataStorage.some((data, index) => {
            return (data.name.toLowerCase() === name || data.email.toLowerCase() === email) && index !== editIndex;
        });

        if (isDuplicate) {
            if (name === dataStorage.find(element => element.name.toLowerCase() === name)?.name.toLowerCase()) {
                alert("The user with NAME already exists");
            } else {
                alert("The user with EMAIL already exists");
            }
            return;
        }

        formData.forEach((value, key) => {
            if (key === 'file') {
                const fileInput = this.elements.namedItem(key) as HTMLInputElement;
                const file = fileInput.files ? fileInput.files[0] : null;
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        jsonObject[key] = e.target?.result;
                        jsonObject[`${key}Name`] = file.name;
                        storeData(jsonObject);
                    };
                    reader.readAsDataURL(file);
                } else {
                    jsonObject[key] = null;
                    storeData(jsonObject);
                }
            } else if (key === 'profession') {
                if (!jsonObject[key]) {
                    jsonObject[key] = [];
                }
                jsonObject[key].push(value);
            } else {
                jsonObject[key] = value;
            }
        });

        if (!formData.has('file')) {
            storeData(jsonObject);
        }
    });

    function storeData(data: any) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data;
            editIndex = null;
        } else {
            dataStorage.push(data);
        }

        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage));
            renderTable();
            $('#multiInputForm').removeClass('was-validated')[0].reset();
        } catch (err) {
            console.log("Error occurred: " + err);
        }
    }

    function renderTable() {
        const dataTable = $('#dataTable tbody');
        dataTable.empty();

        dataStorage.forEach((data, index) => {
            const row = $('<tr>');

            const actions = $('<td>');
            const editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index);
            });
            const deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index);
            });

            actions.append(editButton).append(deleteButton);
            row.append(actions);

            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));
            row.append($('<td>').html(data.file ? `<a href="${data.file}" download="${data.fileName}">${data.fileName}</a>` : ''));

            dataTable.append(row);
        });
    }

    function editData(index: number) {
        const data = dataStorage[index];
        editIndex = index;

        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);

        if (Array.isArray(data.profession)) {
            data.profession.forEach(prof => {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        } else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }

        $('#country').val(data.country);
        $('#textarea').val(data.textarea);
        $('#file').val('');
    }

    function deleteData(index: number) {
        dataStorage.splice(index, 1);
        localStorage.setItem('formData', JSON.stringify(dataStorage));
        renderTable();
    }

    function validateProfession(): boolean {
        if ($('input[name="profession"]:checked').length === 0) {
            $('input[name="profession"]').each(function () {
                $(this).addClass('is-invalid').css('color', 'red');
            });
            alert("Please select any one profession");
            return false;
        } else {
            $('input[name="profession"]').each(function () {
                $(this).removeClass('is-invalid');
            });
            return true;
        }
    }

    $('input[name="profession"]').on('change', function () {
        validateProfession();
    });
});