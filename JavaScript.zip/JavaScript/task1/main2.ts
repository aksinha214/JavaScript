interface FormDataEntry {
    name: string;
    email: string;
    password: string;
    number: string;
    date: string;
    color: string;
    gender: string;
    profession: string[];
    country: string;
    textarea: string;
    files: { fileName: string, fileData: string }[];
}

$(document).ready(function () {
    'use strict';

    let dataStorage: FormDataEntry[] = JSON.parse(localStorage.getItem('formData') || '[]');
    let editIndex: number | null = null;

    renderTable();

    $('#multiInputForm').on('submit', function (event) {
        event.preventDefault();

        const formElement = this as HTMLFormElement;
        const isFormValid = formElement.checkValidity();
        const isProfessionValid = validateProfession();

        if (!isFormValid || !isProfessionValid) {
            event.stopPropagation();
            $(formElement).addClass('was-validated');
            return;
        }

        const formData = new FormData(formElement);
        const jsonObject: any = {};

        const name = formData.get('name')?.toString().trim().toLowerCase();
        const email = formData.get('email')?.toString().trim().toLowerCase();

        const isDuplicate = dataStorage.some((data, index) => {
            return (data.name.toLowerCase() === name || data.email.toLowerCase() === email) && index !== editIndex;
        });

        if (isDuplicate) {
            alert(dataStorage.some(data => data.name.toLowerCase() === name) ? "The user with this NAME already exists." : "The user with this EMAIL already exists.");
            return;
        }

        const files: { fileName: string, fileData: string }[] = [];
        const fileInput = (document.getElementById('file') as HTMLInputElement).files;

        if (fileInput && fileInput.length > 0) {
            const validFiles: Promise<{ fileName: string, fileData: string }>[] = [];
            for (let i = 0; i < fileInput.length; i++) {
                const file = fileInput[i];
                if (!validateFile(file, files)) {
                    return;
                }

                const filePromise = new Promise<{ fileName: string, fileData: string }>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        resolve({ fileName: file.name, fileData: e.target?.result as string });
                    };
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
                validFiles.push(filePromise);
            }

            Promise.all(validFiles).then((fileResults) => {
                files.push(...fileResults);
                collectFormData(formData, jsonObject, files);
            }).catch((error) => {
                console.error("Error reading file:", error);
            });

        } else {
            // No file selected or file input empty, continue without file data
            collectFormData(formData, jsonObject, files);
        }
    });

    function collectFormData(formData: FormData, jsonObject: any, files: { fileName: string, fileData: string }[]) {
        formData.forEach((value, key) => {
            if (key !== 'file') {
                if (key === 'profession') {
                    if (!jsonObject[key]) {
                        jsonObject[key] = [];
                    }
                    jsonObject[key].push(value);
                } else {
                    jsonObject[key] = value;
                }
            }
        });

        if (editIndex !== null && dataStorage[editIndex]) {
            const existingFiles = dataStorage[editIndex].files || [];
            jsonObject['files'] = [...existingFiles, ...files];
        } else {
            jsonObject['files'] = files;
        }

        storeData(jsonObject);
    }

    function storeData(data: any) {
        if (editIndex !== null) {
            dataStorage[editIndex] = data;
            editIndex = null;
        } else {
            dataStorage.push(data);
        }

        try {
            localStorage.setItem('formData', JSON.stringify(dataStorage));
            renderTable();
            const formElement = $('#multiInputForm')[0] as HTMLFormElement;
            $(formElement).removeClass('was-validated');
            formElement.reset();
        } catch (err) {
            console.error("Error occurred while saving data: ", err);
        }
    }

    function renderTable() {
        const dataTable = $('#dataTable');
        dataTable.empty();
        dataStorage.forEach((data, index) => {
            const row = $('<tr>');
            const actions = $('<td>');
            const editButton = $('<button>').text('Edit').addClass('btn btn-warning btn-sm').on('click', function () {
                editData(index);
            });
            const deleteButton = $('<button>').text('Delete').addClass('btn btn-danger btn-sm').on('click', function () {
                deleteData(index);
            });
            actions.append(editButton).append(deleteButton);

            row.append(actions);
            row.append($('<td>').text(data.name));
            row.append($('<td>').text(data.email));
            row.append($('<td>').text(data.password));
            row.append($('<td>').text(data.number));
            row.append($('<td>').text(data.date));
            row.append($('<td>').text(data.color));
            row.append($('<td>').text(data.gender));
            row.append($('<td>').text(Array.isArray(data.profession) ? data.profession.join(', ') : data.profession));
            row.append($('<td>').text(data.country));
            row.append($('<td>').text(data.textarea));

            const fileLinks = (data.files || []).map(file => `<a href="${file.fileData}" download="${file.fileName}">${file.fileName}</a>`).join('<br>');
            row.append($('<td>').html(fileLinks));

            dataTable.append(row);
        });
    }

    function editData(index: number) {
        const data = dataStorage[index];
        editIndex = index;
        $('#name').val(data.name);
        $('#email').val(data.email);
        $('#password').val(data.password);
        $('#number').val(data.number);
        $('#date').val(data.date);
        $('#color').val(data.color);
        $('input[name="gender"][value="' + data.gender + '"]').prop('checked', true);
        $('input[name="profession"]').prop('checked', false);
        if (Array.isArray(data.profession)) {
            data.profession.forEach(prof => {
                $('input[name="profession"][value="' + prof + '"]').prop('checked', true);
            });
        } else {
            $('input[name="profession"][value="' + data.profession + '"]').prop('checked', true);
        }
        $('#country').val(data.country);
        $('#textarea').val(data.textarea);

        if (data.files && data.files.length > 0) {
            const fileNames = data.files.map(file => file.fileName).join(', ');
            $('#fileInfo').text(`Current files: ${fileNames}`);
        } else {
            $('#fileInfo').text('No files uploaded.');
        }
    }

    function deleteData(index: number) {
        dataStorage.splice(index, 1);
        localStorage.setItem('formData', JSON.stringify(dataStorage));
        renderTable();
    }

    function validateProfession(): boolean {
        if ($('input[name="profession"]:checked').length === 0) {
            $('input[name="profession"]').each(function () {
                $(this).addClass('is-invalid').css('color', 'red');
            });
            alert("Please select at least one profession.");
            return false;
        } else {
            $('input[name="profession"]').each(function () {
                $(this).removeClass('is-invalid');
            });
            return true;
        }
    }

    function validateFile(file: File, existingFiles: { fileName: string, fileData: string }[]): boolean {
        const allowedTypes: string[] = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
        const maxSize = 5 * 1024 * 1024; // Maximum file size (5MB)

        let isValidType = allowedTypes.includes(file.type);

        if (!isValidType) {
            alert('Invalid file type. Only JPG, JPEG, PNG, and PDF files are allowed.');
            return false;
        }

        if (file.size > maxSize) {
            alert('File size exceeds the maximum limit of 5MB.');
            return false;
        }

        if (existingFiles.some(existingFile => existingFile.fileName === file.name)) {
            alert('This file already exists in the current entry.');
            return false;
        }

        return true;
    }
});
